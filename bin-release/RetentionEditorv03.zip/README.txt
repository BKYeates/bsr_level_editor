 /$$$$$$$  /$$$$$$ /$$$$$$$$        /$$$$$$  /$$      /$$  /$$$$$$   /$$$$$$  /$$   /$$ /$$$$$$$$ /$$$$$$$ 
| $$__  $$|_  $$_/|__  $$__/       /$$__  $$| $$$    /$$$ /$$__  $$ /$$__  $$| $$  | $$| $$_____/| $$__  $$
| $$  \ $$  | $$     | $$         | $$  \__/| $$$$  /$$$$| $$  \ $$| $$  \__/| $$  | $$| $$      | $$  \ $$
| $$$$$$$   | $$     | $$         |  $$$$$$ | $$ $$/$$ $$| $$$$$$$$|  $$$$$$ | $$$$$$$$| $$$$$   | $$$$$$$/
| $$__  $$  | $$     | $$          \____  $$| $$  $$$| $$| $$__  $$ \____  $$| $$__  $$| $$__/   | $$__  $$
| $$  \ $$  | $$     | $$          /$$  \ $$| $$\  $ | $$| $$  | $$ /$$  \ $$| $$  | $$| $$      | $$  \ $$
| $$$$$$$/ /$$$$$$   | $$         |  $$$$$$/| $$ \/  | $$| $$  | $$|  $$$$$$/| $$  | $$| $$$$$$$$| $$  | $$
|_______/ |______/   |__/          \______/ |__/     |__/|__/  |__/ \______/ |__/  |__/|________/|__/  |__/


/*========================================================================================
									RETENTION EDITOR v0.3
========================================================================================*/

HOW TO USE:

	- Select the stage when the app runs
	- Open all image files from the same directory that you want to be placed in the editor
	- Adjust the level width and level height accordingly on the settings panel to the right (editor will resize to fit the screen in this version, next version I will have a zoom feature)
	- Select a layer from the settings panel (background, midground, or foreground)
	- Start placing tiles
		- After a tile is placed you can move it 1 pixel at a time in the x/y direction using the arrow keys
		- Hold shift to move 10 pixels at a time
		
	- When you are finished hit Save, a file will be exported of type rmf (retention map format, basically a text file with byte code)
	- We will need that file for the game to run (Next version of the overworld will have this being parsed, I'll deploy a version of that so you can see the live version)
	- Use mouse wheel for zooming in and out
	- Hold down space + click and drag to move the level around
	- Select a tile that was placed at any time to adjust it
	- Also when you select a tile, a scale menu will appear if you would like to adjust the scaling. The scaling retains the tiles orientation automatically
	
Bugs:

	- Should any bugs appear email me - bennett.yeates@gmail.com